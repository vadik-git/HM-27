﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HM_27
{
    //4-5 Task
    class Task4 {
        static Random rnd = new Random();
        string fileName = "RandNumb.txt";
        string numbers = "numbers.txt";
        Mutex objMutex = new Mutex();
        string fileNumb7 = "Number7.txt";


        static bool IsPrimeNumber(int n)
        {
            var result = true;

            if (n > 1)
            {
                for (var i = 2u; i < n; i++)
                {
                    if (n % i == 0)
                    {
                        result = false;
                        break;
                    }
                }
            }
            else
            {
                result = false;
            }

            return result;
        }

        public void RandNumbWriteFile(object obj)
        {
            Mutex objMutex = obj as Mutex;
            //Console.WriteLine("Open");
           
            int value;
            objMutex.WaitOne();

          using (StreamWriter sw = new StreamWriter(fileName, false, System.Text.Encoding.Default))
          {
            for (int i = 0; i < 10; ++i)
            {
                    value = rnd.Next(10, 20);
                    sw.WriteLine(value);
            }
          }

            objMutex.ReleaseMutex();
        }


        public void WriteNewFileNumb(object obj)
        {
            Mutex objMutex = obj as Mutex;
            objMutex.WaitOne();
            List<int> list = new List<int>();
            using (StreamReader sr = new StreamReader(fileName))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    int numb  = Convert.ToInt32(line);
                    list.Add(numb);
                }
            }

            using (StreamWriter sw = new StreamWriter(numbers, false, System.Text.Encoding.Default))
            {

                foreach(var i in list)
                {
                    if (IsPrimeNumber(i))
                    {
                        sw.WriteLine(i);
                    }
                }
           


            }

            objMutex.ReleaseMutex();
        }


        public void WriteNumb7(object obj)
        {
            Mutex objMutex = obj as Mutex;
           
            objMutex.WaitOne();
           
            var line = File.ReadAllLines(numbers);
            using (StreamWriter sw = new StreamWriter((fileNumb7)))
            {
                for (int i = 0; i < line.Length; i++)
                {

                    char[] c = line[i].ToCharArray();
                    if (c[c.Length - 1] == '7')
                    {
                        sw.WriteLine(line[i]);

                    }
                }
            }
            objMutex.ReleaseMutex();

        }


        public void Info(object obj)
        {
            Mutex objMutex = obj as Mutex;
            objMutex.WaitOne();
            FileInfo f1 = new FileInfo(fileName);
           // string fileNumb = "numbers.txt";
            FileInfo f2 = new FileInfo(numbers);
            FileInfo f3= new FileInfo(fileNumb7);

            var file1 = File.ReadAllLines(fileName);
            var file2 = File.ReadAllLines(numbers);
            var file3 = File.ReadAllLines(fileNumb7);

            using (StreamWriter sw = new StreamWriter(("Stat.txt"), false))
            {
                sw.WriteLine($"{fileName}\t{f1.Length}-mb\t{file1.Length}");
                sw.WriteLine($"{numbers}\t{f2.Length}-mb\t{file2.Length}");
                sw.WriteLine($"{fileNumb7}\t{f3.Length}-mb\t{file3.Length}");
            }


            Console.WriteLine($"{fileName}\t{f1.Length}-b\t{file1.Length}");

            Console.WriteLine($"{numbers}\t{f2.Length}-b\t{file2.Length}");

            Console.WriteLine($"{fileNumb7}\t{f3.Length}-b\t{file3.Length}");


            objMutex.ReleaseMutex();
        }


    }


    class Program
    {
        static void Main(string[] args)
        {
            
            Task4 task4 = new Task4();
            Mutex mutex = new Mutex(false, "Slob");

            Thread thread1 = new Thread(task4.RandNumbWriteFile);
            thread1.Start(mutex);
            Thread thread2 = new Thread(task4.WriteNewFileNumb);
            thread2.Start(mutex);
            Thread thread3 = new Thread(task4.WriteNumb7);
            thread3.Start(mutex);
            Thread thread4 = new Thread(task4.Info);
            thread4.Start(mutex);


            Console.ReadKey();

        }
    }
}
/*Создайте приложение, использующее механизм мьютексов.Создайте в коде приложения несколько потоков.
Первый поток генерирует набор случайных чисел и записывает их в файл.Второй поток ожидает, когда первый
закончит своё исполнение, после чего анализирует содержимое файла и создаёт новый файл, в котором должны
быть собраны только простые числа из первого файла.
Третий поток ожидает, когда закончится второй поток,
после чего создаёт новый файл, в котором должны быть
собраны все простые числа из второго файла у которых
последняя цифра равна 7. Выбор типа приложения (консольное или оконное, остаётся за вами).

 Задание 5
Добавьте к четвертому заданию четвертый поток, который подготовит и выведет отчет о полученных файлах
в итоговый файл отчёта. Пример отчёта:
■ количество чисел в каждом файле;
■ размер каждого файла в байтах;
■ содержимое каждого из файлов
     
     */
