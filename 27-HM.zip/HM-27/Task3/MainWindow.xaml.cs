﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Mutex mutex = new Mutex(false, "Neptun");

        }
        public void task4()
        {
            Mutex m = null;
            if (!Mutex.TryOpenExisting("Neptun", out m))
            {
                m = new Mutex(true, "Neptun");
            }
            else
            {
                Environment.Exit(0);
            }

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "(*.exe)|*.exe|All files (*.*)|*.*";
            openFileDialog.ShowDialog();
            int count = 0;
            if (count < 3)
            {
                   if (openFileDialog.FileName != null)
                   {
                
                    Process p = new Process();
                    p.StartInfo = new ProcessStartInfo(openFileDialog.FileName);
                    p.Start();

                    Thread thread = new Thread(task4);
                    thread.Start();
                    count++;
                
                    }
            }
            else
            {
                MessageBox.Show($"Error count open prog = {count}");
            }

        }
    }
}
