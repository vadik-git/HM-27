﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskCasino
{
   public  class Player
    {
        public int StartSum { get; set; }
        public int EndSum { get; set; }
    }
}
