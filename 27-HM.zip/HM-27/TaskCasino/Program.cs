﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskCasino
{
    class Program
    {
        static void Main(string[] args)
        {

            Mutex mutex = new Mutex();
            Thread[] threads = new Thread[5];
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(Game);
            }
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].Start(mutex);
            }

        }



        static void Game(object obj)
        {
            Mutex mutex = obj as Mutex;
            mutex.WaitOne();
            Random rnd = new Random();
            Player pleyer = new Player()
            {
                StartSum = 1000,
                EndSum = 0
            };
            while (pleyer.StartSum != 0)
            {
                int rate = rnd.Next(1000);
                if (rate > pleyer.StartSum)
                {
                    using (StreamWriter writer = new StreamWriter(("Stat.txt"), false))
                    {
                        writer.WriteLine($"Player{Thread.CurrentThread.ManagedThreadId}\t{pleyer.StartSum}\t {pleyer.EndSum}");

                    }
                    break;
                }
                else
                {
                    pleyer.StartSum -= rate;
                    int numb = rnd.Next(10);
                    int rateNumb = rnd.Next(10);
                    Console.WriteLine($"Rate->{rate}\t Number->{numb}\t Rate number->{rateNumb}");
                    if (numb == rateNumb)
                    {
                        pleyer.EndSum += pleyer.StartSum + (rate * rate);
                    }
                    else
                    {
                        pleyer.StartSum -= rate;
                    }
                }
                Thread.Sleep(0);
            }
            using (StreamWriter writer = new StreamWriter(("Stat.txt"), false))
            {
                writer.WriteLine($"Player{Thread.CurrentThread.ManagedThreadId}\t{pleyer.StartSum}\t {pleyer.EndSum}");
            }
            mutex.ReleaseMutex();
        }

    }


}
